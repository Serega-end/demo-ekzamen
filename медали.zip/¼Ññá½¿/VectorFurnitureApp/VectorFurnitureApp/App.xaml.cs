﻿using System.Windows;

namespace VectorFurniture
{
    public partial class App : Application
    {
    }
}