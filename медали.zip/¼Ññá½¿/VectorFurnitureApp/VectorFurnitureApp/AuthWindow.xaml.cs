﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using VectorFurniture.Services;

namespace VectorFurniture
{
    public partial class AuthWindow : global::System.Windows.Window
    {
        // ============================================================
        //  РАЗМЕР СЕТКИ ПАЗЛА:
        //    2  ->  4 части (как сейчас)
        //    3  ->  9 частей
        //    4  -> 16 частей
        // ============================================================
        private const int GridSize = 2;
        private const int BoardSize = 300;

        private int _tileSize;
        private int[] _currentOrder = Array.Empty<int>();
        private readonly List<Image> _tileImages = new List<Image>();
        private int _selectedIndex = -1;
        private bool _captchaSolved;
        private bool _ready;

        private readonly DatabaseService _dbService;
        private readonly Random _random = new Random();

        public AuthWindow()
        {
            InitializeComponent();
            _dbService = new DatabaseService();
            GeneratePuzzleCaptcha();
            _ready = true;
        }

        private void RefreshCaptchaBtn_Click(object sender, global::System.Windows.RoutedEventArgs e)
        {
            GeneratePuzzleCaptcha();
        }

        // ============================================================
        // ГЕНЕРАЦИЯ ПАЗЛА
        // ============================================================
        private void GeneratePuzzleCaptcha()
        {
            _captchaSolved = false;
            _selectedIndex = -1;

            CaptchaStatusText.Text = "Соберите человечка: кликните по двум частям, чтобы поменять их местами";
            CaptchaStatusText.Foreground = Brushes.Gray;
            PuzzleBorder.BorderBrush = Brushes.Gray;

            _tileSize = BoardSize / GridSize;

            var fullImage = DrawMan(BoardSize, BoardSize);

            var tiles = new List<BitmapSource>();
            for (int row = 0; row < GridSize; row++)
            {
                for (int col = 0; col < GridSize; col++)
                {
                    var rect = new global::System.Windows.Int32Rect(
                        col * _tileSize, row * _tileSize, _tileSize, _tileSize);
                    tiles.Add(new CroppedBitmap(fullImage, rect));
                }
            }

            int total = GridSize * GridSize;
            _currentOrder = Enumerable.Range(0, total).ToArray();
            do
            {
                ShuffleArray(_currentOrder);
            }
            while (IsSolvedInternal());

            PuzzleBoard.Children.Clear();
            PuzzleBoard.Rows = GridSize;
            PuzzleBoard.Columns = GridSize;
            PuzzleBoard.Width = BoardSize;
            PuzzleBoard.Height = BoardSize;
            _tileImages.Clear();

            for (int i = 0; i < total; i++)
            {
                var img = new Image
                {
                    Source = tiles[_currentOrder[i]],
                    Width = _tileSize,
                    Height = _tileSize,
                    Stretch = Stretch.Fill,
                    Cursor = Cursors.Hand,
                    Tag = i
                };
                img.MouseLeftButtonDown += Tile_Click;
                _tileImages.Add(img);
                PuzzleBoard.Children.Add(img);
            }
        }

        // ============================================================
        // РИСУЕМ ЧЕЛОВЕЧКА — увеличенные пропорции для 2×2 сетки
        // ============================================================
        private BitmapSource DrawMan(int width, int height)
        {
            var visual = new DrawingVisual();
            using (var dc = visual.RenderOpen())
            {
                // --- Фон ---
                var bgBrush = new LinearGradientBrush(
                    Color.FromRgb(230, 240, 255),
                    Color.FromRgb(180, 210, 240),
                    new global::System.Windows.Point(0, 0),
                    new global::System.Windows.Point(0, 1));
                dc.DrawRectangle(bgBrush, null, new global::System.Windows.Rect(0, 0, width, height));

                // --- Пропорции (увеличены под 2×2) ---
                double cx = width / 2.0;   // 150

                var skinBrush = new SolidColorBrush(Color.FromRgb(255, 220, 180));
                var shirtBrush = new SolidColorBrush(Color.FromRgb(70, 130, 200));
                var pantsBrush = new SolidColorBrush(Color.FromRgb(60, 60, 90));
                var hairBrush = new SolidColorBrush(Color.FromRgb(80, 50, 30));
                var shoeBrush = new SolidColorBrush(Color.FromRgb(30, 30, 30));
                var outline = new Pen(new SolidColorBrush(Color.FromRgb(40, 40, 40)), 2.5);
                var smilePen = new Pen(new SolidColorBrush(Color.FromRgb(40, 40, 40)), 2.5);

                // --- ГОЛОВА ---
                double headR = 48;
                double headY = 75;   // центр головы в верхней половине
                dc.DrawEllipse(hairBrush, null, new global::System.Windows.Point(cx, headY - 6), headR, headR);
                dc.DrawEllipse(skinBrush, outline, new global::System.Windows.Point(cx, headY), headR, headR);

                // Глаза
                dc.DrawEllipse(Brushes.Black, null, new global::System.Windows.Point(cx - 17, headY - 8), 5, 7);
                dc.DrawEllipse(Brushes.Black, null, new global::System.Windows.Point(cx + 17, headY - 8), 5, 7);

                // Блики в глазах
                dc.DrawEllipse(Brushes.White, null, new global::System.Windows.Point(cx - 15, headY - 10), 1.5, 2);
                dc.DrawEllipse(Brushes.White, null, new global::System.Windows.Point(cx + 19, headY - 10), 1.5, 2);

                // Улыбка
                var smileGeo = new StreamGeometry();
                using (var ctx = smileGeo.Open())
                {
                    ctx.BeginFigure(new global::System.Windows.Point(cx - 18, headY + 18), false, false);
                    ctx.ArcTo(
                        new global::System.Windows.Point(cx + 18, headY + 18),
                        new global::System.Windows.Size(18, 12),
                        0,
                        false,
                        SweepDirection.Clockwise,
                        true,
                        false);
                }
                smileGeo.Freeze();
                dc.DrawGeometry(null, smilePen, smileGeo);

                // --- ТУЛОВИЩЕ ---
                double bodyTop = headY + headR + 6;
                double bodyW = 95;
                double bodyH = 95;
                var bodyRect = new global::System.Windows.Rect(cx - bodyW / 2, bodyTop, bodyW, bodyH);
                dc.DrawRoundedRectangle(shirtBrush, outline, bodyRect, 16, 16);

                // Воротник
                dc.DrawLine(outline,
                    new global::System.Windows.Point(cx - 20, bodyTop),
                    new global::System.Windows.Point(cx, bodyTop + 14));
                dc.DrawLine(outline,
                    new global::System.Windows.Point(cx + 20, bodyTop),
                    new global::System.Windows.Point(cx, bodyTop + 14));

                // --- РУКИ ---
                double armW = 22;
                double armTop = bodyTop + 10;
                double armLen = 80;
                dc.DrawRoundedRectangle(skinBrush, outline,
                    new global::System.Windows.Rect(cx - bodyW / 2 - armW + 6, armTop, armW, armLen), 8, 8);
                dc.DrawRoundedRectangle(skinBrush, outline,
                    new global::System.Windows.Rect(cx + bodyW / 2 - 6, armTop, armW, armLen), 8, 8);

                // --- НОГИ ---
                double legTop = bodyTop + bodyH - 6;
                double legW = 32;
                double legLen = 85;
                dc.DrawRoundedRectangle(pantsBrush, outline,
                    new global::System.Windows.Rect(cx - 34, legTop, legW, legLen), 8, 8);
                dc.DrawRoundedRectangle(pantsBrush, outline,
                    new global::System.Windows.Rect(cx + 2, legTop, legW, legLen), 8, 8);

                // --- БОТИНКИ ---
                dc.DrawRoundedRectangle(shoeBrush, null,
                    new global::System.Windows.Rect(cx - 38, legTop + legLen - 8, legW + 8, 18), 5, 5);
                dc.DrawRoundedRectangle(shoeBrush, null,
                    new global::System.Windows.Rect(cx - 2, legTop + legLen - 8, legW + 8, 18), 5, 5);

                // --- Разделительные линии ---
                var guidePen = new Pen(new SolidColorBrush(Color.FromArgb(35, 0, 0, 0)), 1);
                for (int i = 1; i < GridSize; i++)
                {
                    dc.DrawLine(guidePen,
                        new global::System.Windows.Point(i * _tileSize, 0),
                        new global::System.Windows.Point(i * _tileSize, height));
                    dc.DrawLine(guidePen,
                        new global::System.Windows.Point(0, i * _tileSize),
                        new global::System.Windows.Point(width, i * _tileSize));
                }
            }

            var bmp = new RenderTargetBitmap(width, height, 96, 96, PixelFormats.Pbgra32);
            bmp.Render(visual);
            bmp.Freeze();
            return bmp;
        }

        // ============================================================
        // ПЕРЕМЕШИВАНИЕ И ПРОВЕРКА
        // ============================================================
        private void ShuffleArray(int[] array)
        {
            for (int i = array.Length - 1; i > 0; i--)
            {
                int j = _random.Next(i + 1);
                (array[i], array[j]) = (array[j], array[i]);
            }
        }

        private bool IsSolvedInternal()
        {
            for (int i = 0; i < _currentOrder.Length; i++)
                if (_currentOrder[i] != i) return false;
            return true;
        }

        // ============================================================
        // КЛИК ПО ПЛИТКЕ — свап
        // ============================================================
        private void Tile_Click(object sender, MouseButtonEventArgs e)
        {
            if (!_ready || _captchaSolved) return;

            var img = (Image)sender;
            int pos = (int)img.Tag;

            if (_selectedIndex == -1)
            {
                _selectedIndex = pos;
                img.Opacity = 0.55;
            }
            else if (_selectedIndex == pos)
            {
                img.Opacity = 1.0;
                _selectedIndex = -1;
            }
            else
            {
                int posA = _selectedIndex;
                int posB = pos;

                (_currentOrder[posA], _currentOrder[posB]) =
                    (_currentOrder[posB], _currentOrder[posA]);

                (_tileImages[posA].Source, _tileImages[posB].Source) =
                    (_tileImages[posB].Source, _tileImages[posA].Source);

                _tileImages[posA].Opacity = 1.0;
                _selectedIndex = -1;

                if (IsSolvedInternal())
                {
                    _captchaSolved = true;
                    CaptchaStatusText.Text = "✓ Человечек собран! Проверка пройдена.";
                    CaptchaStatusText.Foreground = Brushes.Green;
                    PuzzleBorder.BorderBrush = Brushes.Green;
                }
            }
        }

        // ============================================================
        // ВХОД
        // ============================================================
        private async void LoginBtn_Click(object sender, global::System.Windows.RoutedEventArgs e)
        {
            LoginErrorText.Text = "";

            if (!_captchaSolved)
            {
                LoginErrorText.Text = "Соберите человечка!";
                return;
            }

            string login = LoginTextBox.Text.Trim();
            string password = LoginPasswordBox.Password;

            if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password))
            {
                LoginErrorText.Text = "Введите логин и пароль.";
                return;
            }

            bool isValid = await _dbService.AuthenticateUserAsync(login, password);

            if (isValid)
            {
                var mainWindow = new MainWindow();
                mainWindow.Show();
                this.Close();
            }
            else
            {
                LoginErrorText.Text = "Неверный логин или пароль.";
                GeneratePuzzleCaptcha();
            }
        }

        // ============================================================
        // РЕГИСТРАЦИЯ
        // ============================================================
        private async void RegisterBtn_Click(object sender, global::System.Windows.RoutedEventArgs e)
        {
            RegErrorText.Text = "";
            string login = RegLoginTextBox.Text.Trim();
            string password = RegPasswordBox.Password;
            string confirmPassword = RegConfirmPasswordBox.Password;

            if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password))
            {
                RegErrorText.Text = "Заполните все поля.";
                return;
            }

            if (password != confirmPassword)
            {
                RegErrorText.Text = "Пароли не совпадают.";
                return;
            }

            try
            {
                await _dbService.RegisterUserAsync(login, password);
                global::System.Windows.MessageBox.Show("Пользователь успешно зарегистрирован!",
                    "Успех", global::System.Windows.MessageBoxButton.OK,
                    global::System.Windows.MessageBoxImage.Information);

                RegLoginTextBox.Clear();
                RegPasswordBox.Clear();
                RegConfirmPasswordBox.Clear();
                AuthTabControl.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                RegErrorText.Text = "Ошибка регистрации: " + ex.Message;
            }
        }
    }
}