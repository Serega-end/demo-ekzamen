﻿using System;
using System.Windows;
using VectorFurniture.Models;
using VectorFurniture.Services;

namespace VectorFurniture
{
    public partial class MainWindow : Window
    {
        private readonly DatabaseService _dbService;

        public MainWindow()
        {
            InitializeComponent();
            _dbService = new DatabaseService();
            Loaded += MainWindow_Loaded;
        }

        private async void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            await LoadPartnersAsync();
        }

        private async System.Threading.Tasks.Task LoadPartnersAsync()
        {
            try
            {
                StatusText.Text = "Загрузка...";
                var list = await _dbService.GetPartnersAsync();
                PartnersGrid.ItemsSource = list;
                StatusText.Text = $"Загружено партнёров: {list.Count}";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Не удалось загрузить список партнёров.\n\n{ex.Message}",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                StatusText.Text = "Ошибка загрузки";
            }
        }

        private void AddBtn_Click(object sender, RoutedEventArgs e)
        {
            var editWindow = new PartnerEditWindow { Owner = this };
            if (editWindow.ShowDialog() == true)
                _ = LoadPartnersAsync();
        }

        private async void EditBtn_Click(object sender, RoutedEventArgs e)
        {
            if (PartnersGrid.SelectedItem is not PartnerRow selected)
            {
                MessageBox.Show("Сначала выберите партнёра в таблице.",
                    "Внимание", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            var fullPartner = await _dbService.GetPartnerByIdAsync(selected.Id);
            if (fullPartner == null)
            {
                MessageBox.Show("Не удалось загрузить данные партнёра.",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            var editWindow = new PartnerEditWindow(fullPartner) { Owner = this };
            if (editWindow.ShowDialog() == true)
                _ = LoadPartnersAsync();
        }

        private void HistoryBtn_Click(object sender, RoutedEventArgs e)
        {
            if (PartnersGrid.SelectedItem is not PartnerRow selected)
            {
                MessageBox.Show("Сначала выберите партнёра в таблице.",
                    "Внимание", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            var historyWindow = new PartnerHistoryWindow(selected.Id, selected.PartnerName)
            {
                Owner = this
            };
            historyWindow.ShowDialog();
        }

        private void MaterialBtn_Click(object sender, RoutedEventArgs e)
        {
            var materialWindow = new MaterialCalculationWindow { Owner = this };
            materialWindow.ShowDialog();
        }

        private async void RefreshBtn_Click(object sender, RoutedEventArgs e)
        {
            await LoadPartnersAsync();
        }

        private void LogoutBtn_Click(object sender, RoutedEventArgs e)
        {
            var authWindow = new AuthWindow();
            authWindow.Show();
            this.Close();
        }
    }
}