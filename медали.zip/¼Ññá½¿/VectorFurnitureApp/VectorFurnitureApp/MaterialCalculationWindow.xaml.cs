﻿using System;
using System.Windows;
using VectorFurniture.Services;

namespace VectorFurniture
{
    public partial class MaterialCalculationWindow : Window
    {
        private readonly DatabaseService _dbService;

        public MaterialCalculationWindow()
        {
            InitializeComponent();
            _dbService = new DatabaseService();
        }

        private async void CalcBtn_Click(object sender, RoutedEventArgs e)
        {
            if (!int.TryParse(ProductTypeIdBox.Text, out int productTypeId) ||
                !int.TryParse(MaterialTypeIdBox.Text, out int materialTypeId) ||
                !int.TryParse(QuantityBox.Text, out int quantity) ||
                !double.TryParse(Param1Box.Text.Replace('.', ','), out double param1) ||
                !double.TryParse(Param2Box.Text.Replace('.', ','), out double param2))
            {
                ResultText.Text = "❌ Все поля должны быть заполнены корректными числами.";
                return;
            }

            int result;
            try
            {
                result = await _dbService.CalculateMaterialAsync(
                    productTypeId, materialTypeId, quantity, param1, param2);
            }
            catch (Exception ex)
            {
                ResultText.Text = $"❌ Ошибка при обращении к БД: {ex.Message}";
                return;
            }

            if (result < 0)
            {
                ResultText.Text = "❌ Некорректные данные.\n\n" +
                                  "Проверьте:\n" +
                                  "• ID типа продукции и материала существуют в БД;\n" +
                                  "• количество — целое положительное число;\n" +
                                  "• оба параметра изделия — положительные числа.";
            }
            else
            {
                ResultText.Text = $"✓ Необходимое количество материала: {result} ед.\n\n" +
                                  $"Расчёт с учётом коэффициента типа продукции\n" +
                                  $"и процента брака типа материала.";
            }
        }
    }
}