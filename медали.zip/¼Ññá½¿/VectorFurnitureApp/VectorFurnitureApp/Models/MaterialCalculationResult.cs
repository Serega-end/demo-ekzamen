﻿namespace VectorFurniture.Models
{
    public class MaterialCalculationResult
    {
        public int MaterialAmount { get; set; }
        public string Message { get; set; } = string.Empty;
        public bool IsSuccess { get; set; }
    }
}