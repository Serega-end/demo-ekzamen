﻿namespace VectorFurniture.Models
{
    public class PartnerEditModel
    {
        public int? Id { get; set; }
        public string PartnerType { get; set; } = string.Empty;
        public string PartnerName { get; set; } = string.Empty;
        public string Director { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string Phone { get; set; } = string.Empty;
        public string LegalAddress { get; set; } = string.Empty;
        public string Inn { get; set; } = string.Empty;
        public int Rating { get; set; }
    }
}