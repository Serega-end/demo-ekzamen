﻿using System;

namespace VectorFurniture.Models
{
    public class PartnerHistoryRow
    {
        public string ProductName { get; set; } = string.Empty;
        public int Quantity { get; set; }
        public DateTime SaleDate { get; set; }
    }
}