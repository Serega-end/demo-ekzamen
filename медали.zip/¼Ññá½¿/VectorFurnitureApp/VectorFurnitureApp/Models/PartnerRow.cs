﻿namespace VectorFurniture.Models
{
    public class PartnerRow
    {
        public int Id { get; set; }
        public string PartnerType { get; set; } = string.Empty;
        public string PartnerName { get; set; } = string.Empty;
        public string Director { get; set; } = string.Empty;
        public string Phone { get; set; } = string.Empty;
        public int Rating { get; set; }
        public int TotalQuantity { get; set; }
        public int DiscountPercent { get; set; }
    }
}