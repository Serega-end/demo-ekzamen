﻿using System;
using System.Windows;
using VectorFurniture.Models;
using VectorFurniture.Services;

namespace VectorFurniture
{
    public partial class PartnerHistoryWindow : Window
    {
        private readonly DatabaseService _dbService;

        public PartnerHistoryWindow(int partnerId, string partnerName)
        {
            InitializeComponent();
            _dbService = new DatabaseService();
            PartnerNameText.Text = $"История реализации: {partnerName}";
            Loaded += async (s, e) => await LoadHistoryAsync(partnerId);
        }

        private async System.Threading.Tasks.Task LoadHistoryAsync(int partnerId)
        {
            try
            {
                var history = await _dbService.GetPartnerHistoryAsync(partnerId);
                HistoryGrid.ItemsSource = history;

                int totalQty = 0;
                foreach (var row in history) totalQty += row.Quantity;

                SummaryText.Text = $"Всего записей: {history.Count}    |    " +
                                   $"Общее количество: {totalQty}    |    " +
                                   $"Скидка: {DiscountCalculator.Calculate(totalQty)}%";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Не удалось загрузить историю продаж.\n\n{ex.Message}",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BackBtn_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}