﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Npgsql;
using NpgsqlTypes;
using VectorFurniture.Models;

namespace VectorFurniture.Services
{
    public class DatabaseService
    {
        // ⚠ ЗАМЕНИТЕ пароль, если он у вас другой
        private const string ConnectionString =
            "Host=localhost;Port=5432;Database=vektormebel;" +
            "Username=postgres;Password=1111";

        // ============================================================
        // СПИСОК ПАРТНЁРОВ ДЛЯ ГЛАВНОЙ ФОРМЫ (Модуль №2)
        // ============================================================
        public async Task<List<PartnerRow>> GetPartnersAsync()
        {
            var result = new List<PartnerRow>();
            const string sql = @"
                SELECT p.id, p.partner_type, p.name, p.director, p.phone, p.rating,
                       COALESCE(SUM(pp.quantity), 0) AS total_quantity
                FROM partners p
                LEFT JOIN partner_products pp ON pp.partner_id = p.id
                GROUP BY p.id, p.partner_type, p.name, p.director, p.phone, p.rating
                ORDER BY p.name;";

            await using var conn = new NpgsqlConnection(ConnectionString);
            await conn.OpenAsync();
            await using var cmd = new NpgsqlCommand(sql, conn);
            await using var reader = await cmd.ExecuteReaderAsync();

            while (await reader.ReadAsync())
            {
                int total = Convert.ToInt32(reader.GetValue(6));
                result.Add(new PartnerRow
                {
                    Id = reader.GetInt32(0),
                    PartnerType = reader.GetString(1),
                    PartnerName = reader.GetString(2),
                    Director = reader.GetString(3),
                    Phone = reader.IsDBNull(4) ? "" : reader.GetString(4),
                    Rating = reader.GetInt32(5),
                    TotalQuantity = total,
                    DiscountPercent = DiscountCalculator.Calculate(total)
                });
            }
            return result;
        }

        // ============================================================
        // ИСТОРИЯ РЕАЛИЗАЦИИ ПАРТНЁРА (Модуль №4.1)
        // ============================================================
        public async Task<List<PartnerHistoryRow>> GetPartnerHistoryAsync(int partnerId)
        {
            var result = new List<PartnerHistoryRow>();
            const string sql = @"
                SELECT pr.name, pp.quantity, pp.sale_date
                FROM partner_products pp
                INNER JOIN products pr ON pr.id = pp.product_id
                WHERE pp.partner_id = @pid
                ORDER BY pp.sale_date DESC;";

            await using var conn = new NpgsqlConnection(ConnectionString);
            await conn.OpenAsync();
            await using var cmd = new NpgsqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("pid", NpgsqlDbType.Integer, partnerId);
            await using var reader = await cmd.ExecuteReaderAsync();

            while (await reader.ReadAsync())
            {
                result.Add(new PartnerHistoryRow
                {
                    ProductName = reader.GetString(0),
                    Quantity = reader.GetInt32(1),
                    SaleDate = reader.GetDateTime(2)
                });
            }
            return result;
        }

        // ============================================================
        // РАСЧЁТ МАТЕРИАЛА (Модуль №4.2)
        // ⚠ Таблицы в БД: product_type, material_type (единственное число)
        // ============================================================
        public async Task<int> CalculateMaterialAsync(
            int productTypeId, int materialTypeId, int quantity,
            double param1, double param2)
        {
            // 1. Валидация входных данных
            if (productTypeId <= 0) return -1;
            if (materialTypeId <= 0) return -1;
            if (quantity <= 0) return -1;
            if (param1 <= 0 || param2 <= 0) return -1;

            await using var conn = new NpgsqlConnection(ConnectionString);
            await conn.OpenAsync();

            // 2. Получаем коэффициент типа продукции
            //    ⚠ Таблица: product_type (ед. число!)
            double coefficient;
            const string sqlPT = "SELECT coefficient FROM product_type WHERE id = @id;";
            await using (var cmd = new NpgsqlCommand(sqlPT, conn))
            {
                cmd.Parameters.AddWithValue("id", NpgsqlDbType.Integer, productTypeId);
                var res = await cmd.ExecuteScalarAsync();
                if (res == null || res == DBNull.Value) return -1;
                coefficient = Convert.ToDouble(res);
            }

            // 3. Получаем процент брака типа материала
            //    ⚠ Таблица: material_type (ед. число!)
            double defectPercent;
            const string sqlMT = "SELECT defect_percent FROM material_type WHERE id = @id;";
            await using (var cmd = new NpgsqlCommand(sqlMT, conn))
            {
                cmd.Parameters.AddWithValue("id", NpgsqlDbType.Integer, materialTypeId);
                var res = await cmd.ExecuteScalarAsync();
                if (res == null || res == DBNull.Value) return -1;
                defectPercent = Convert.ToDouble(res);
            }

            // 4. Расчёт
            //    На ед. = param1 × param2 × coefficient
            //    Всего  = на ед. × quantity
            //    С браком = всего × (1 + defectPercent / 100)
            double perUnit = param1 * param2 * coefficient;
            double total = perUnit * quantity;
            double withDefect = total * (1.0 + defectPercent / 100.0);

            // 5. Округляем вверх до целого
            int finalAmount = (int)Math.Ceiling(withDefect);
            return finalAmount;
        }

        // ============================================================
        // ПРОВЕРКА УНИКАЛЬНОСТИ ИНН (Модуль №3)
        // ============================================================
        public async Task<bool> InnExistsAsync(string inn, int? excludeId)
        {
            const string sql = @"
                SELECT COUNT(*) FROM partners
                WHERE inn = @inn AND (@excludeId IS NULL OR id <> @excludeId);";

            await using var conn = new NpgsqlConnection(ConnectionString);
            await conn.OpenAsync();
            await using var cmd = new NpgsqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("inn", NpgsqlDbType.Varchar, inn);
            cmd.Parameters.AddWithValue("excludeId", NpgsqlDbType.Integer,
                (object?)excludeId ?? DBNull.Value);

            var count = (long)(await cmd.ExecuteScalarAsync() ?? 0L);
            return count > 0;
        }

        // ============================================================
        // ПОЛУЧИТЬ ПАРТНЁРА ПО ID (для формы редактирования)
        // ============================================================
        public async Task<PartnerEditModel?> GetPartnerByIdAsync(int id)
        {
            const string sql = @"
                SELECT id, partner_type, name, director,
                       email, phone, legal_address, inn, rating
                FROM partners WHERE id = @id;";

            await using var conn = new NpgsqlConnection(ConnectionString);
            await conn.OpenAsync();
            await using var cmd = new NpgsqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("id", NpgsqlDbType.Integer, id);
            await using var r = await cmd.ExecuteReaderAsync();
            if (!await r.ReadAsync()) return null;

            return new PartnerEditModel
            {
                Id = r.GetInt32(0),
                PartnerType = r.GetString(1),
                PartnerName = r.GetString(2),
                Director = r.GetString(3),
                Email = r.IsDBNull(4) ? "" : r.GetString(4),
                Phone = r.IsDBNull(5) ? "" : r.GetString(5),
                LegalAddress = r.IsDBNull(6) ? "" : r.GetString(6),
                Inn = r.GetString(7),
                Rating = r.GetInt32(8)
            };
        }

        // ============================================================
        // ДОБАВИТЬ НОВОГО ПАРТНЁРА
        // ============================================================
        public async Task InsertPartnerAsync(PartnerEditModel m)
        {
            const string sql = @"
                INSERT INTO partners
                    (partner_type, name, director, email, phone,
                     legal_address, inn, rating)
                VALUES
                    (@t, @n, @d, @e, @p, @a, @inn, @r);";

            await using var conn = new NpgsqlConnection(ConnectionString);
            await conn.OpenAsync();
            await using var cmd = new NpgsqlCommand(sql, conn);

            cmd.Parameters.AddWithValue("t", NpgsqlDbType.Varchar, m.PartnerType);
            cmd.Parameters.AddWithValue("n", NpgsqlDbType.Varchar, m.PartnerName);
            cmd.Parameters.AddWithValue("d", NpgsqlDbType.Varchar, m.Director);
            cmd.Parameters.AddWithValue("e", NpgsqlDbType.Varchar,
                string.IsNullOrWhiteSpace(m.Email) ? (object)DBNull.Value : m.Email);
            cmd.Parameters.AddWithValue("p", NpgsqlDbType.Varchar,
                string.IsNullOrWhiteSpace(m.Phone) ? (object)DBNull.Value : m.Phone);
            cmd.Parameters.AddWithValue("a", NpgsqlDbType.Text,
                string.IsNullOrWhiteSpace(m.LegalAddress) ? (object)DBNull.Value : m.LegalAddress);
            cmd.Parameters.AddWithValue("inn", NpgsqlDbType.Varchar, m.Inn);
            cmd.Parameters.AddWithValue("r", NpgsqlDbType.Integer, m.Rating);

            await cmd.ExecuteNonQueryAsync();
        }

        // ============================================================
        // ОБНОВИТЬ СУЩЕСТВУЮЩЕГО ПАРТНЁРА
        // ============================================================
        public async Task UpdatePartnerAsync(PartnerEditModel m)
        {
            const string sql = @"
                UPDATE partners
                SET partner_type = @t,
                    name = @n,
                    director = @d,
                    email = @e,
                    phone = @p,
                    legal_address = @a,
                    inn = @inn,
                    rating = @r
                WHERE id = @id;";

            await using var conn = new NpgsqlConnection(ConnectionString);
            await conn.OpenAsync();
            await using var cmd = new NpgsqlCommand(sql, conn);

            cmd.Parameters.AddWithValue("t", NpgsqlDbType.Varchar, m.PartnerType);
            cmd.Parameters.AddWithValue("n", NpgsqlDbType.Varchar, m.PartnerName);
            cmd.Parameters.AddWithValue("d", NpgsqlDbType.Varchar, m.Director);
            cmd.Parameters.AddWithValue("e", NpgsqlDbType.Varchar,
                string.IsNullOrWhiteSpace(m.Email) ? (object)DBNull.Value : m.Email);
            cmd.Parameters.AddWithValue("p", NpgsqlDbType.Varchar,
                string.IsNullOrWhiteSpace(m.Phone) ? (object)DBNull.Value : m.Phone);
            cmd.Parameters.AddWithValue("a", NpgsqlDbType.Text,
                string.IsNullOrWhiteSpace(m.LegalAddress) ? (object)DBNull.Value : m.LegalAddress);
            cmd.Parameters.AddWithValue("inn", NpgsqlDbType.Varchar, m.Inn);
            cmd.Parameters.AddWithValue("r", NpgsqlDbType.Integer, m.Rating);
            cmd.Parameters.AddWithValue("id", NpgsqlDbType.Integer, m.Id!.Value);

            await cmd.ExecuteNonQueryAsync();
        }

        // ============================================================
        // АВТОРИЗАЦИЯ ПОЛЬЗОВАТЕЛЯ
        // ============================================================
        public async Task<bool> AuthenticateUserAsync(string login, string password)
        {
            const string sql = "SELECT password_hash FROM users WHERE login = @login;";
            await using var conn = new NpgsqlConnection(ConnectionString);
            await conn.OpenAsync();
            await using var cmd = new NpgsqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("login", NpgsqlDbType.Varchar, login);
            var storedHash = (string?)await cmd.ExecuteScalarAsync();
            if (storedHash == null) return false;
            return storedHash == password;
        }

        // ============================================================
        // РЕГИСТРАЦИЯ ПОЛЬЗОВАТЕЛЯ
        // ============================================================
        public async Task RegisterUserAsync(string login, string password)
        {
            const string sql = "INSERT INTO users (login, password_hash) VALUES (@login, @hash);";
            await using var conn = new NpgsqlConnection(ConnectionString);
            await conn.OpenAsync();
            await using var cmd = new NpgsqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("login", NpgsqlDbType.Varchar, login);
            cmd.Parameters.AddWithValue("hash", NpgsqlDbType.Varchar, password);
            await cmd.ExecuteNonQueryAsync();
        }
    }
}