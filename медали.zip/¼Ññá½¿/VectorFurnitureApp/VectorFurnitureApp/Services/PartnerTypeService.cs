﻿using System.Collections.Generic;

namespace VectorFurniture.Services
{
    public static class PartnerTypeService
    {
        public static List<string> GetTypes() => new List<string>
        {
            "ООО", "АО", "ПАО", "ЗАО"
        };
    }
}