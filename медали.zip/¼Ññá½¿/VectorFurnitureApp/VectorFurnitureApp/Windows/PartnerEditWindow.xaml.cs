﻿using System;
using VectorFurniture.Models;
using VectorFurniture.Services;

namespace VectorFurniture
{
    public partial class PartnerEditWindow : global::System.Windows.Window
    {
        private readonly DatabaseService _dbService;
        private readonly int? _partnerId;

        public PartnerEditWindow(PartnerEditModel? partner = null)
        {
            InitializeComponent();
            _dbService = new DatabaseService();

            if (partner != null)
            {
                _partnerId = partner.Id;
                Title = "Редактирование партнёра";
                TypeComboBox.Text = partner.PartnerType;
                NameTextBox.Text = partner.PartnerName;
                DirectorTextBox.Text = partner.Director;
                EmailTextBox.Text = partner.Email;
                PhoneTextBox.Text = partner.Phone;
                AddressTextBox.Text = partner.LegalAddress;
                InnTextBox.Text = partner.Inn;
                RatingTextBox.Text = partner.Rating.ToString();
            }
            else
            {
                Title = "Добавление партнёра";
                _partnerId = null;
            }
        }

        private async void SaveBtn_Click(object sender, global::System.Windows.RoutedEventArgs e)
        {
            string type = TypeComboBox.Text.Trim();
            string name = NameTextBox.Text.Trim();
            string director = DirectorTextBox.Text.Trim();
            string email = EmailTextBox.Text.Trim();
            string phone = PhoneTextBox.Text.Trim();
            string address = AddressTextBox.Text.Trim();
            string inn = InnTextBox.Text.Trim();
            string ratingStr = RatingTextBox.Text.Trim();

            if (string.IsNullOrEmpty(type) || string.IsNullOrEmpty(name) || string.IsNullOrEmpty(inn))
            {
                global::System.Windows.MessageBox.Show(
                    "Поля 'Тип', 'Наименование' и 'ИНН' обязательны!",
                    "Ошибка", global::System.Windows.MessageBoxButton.OK,
                    global::System.Windows.MessageBoxImage.Warning);
                return;
            }

            if (!int.TryParse(ratingStr, out int rating))
            {
                global::System.Windows.MessageBox.Show("Рейтинг должен быть целым числом!",
                    "Ошибка", global::System.Windows.MessageBoxButton.OK,
                    global::System.Windows.MessageBoxImage.Warning);
                return;
            }

            try
            {
                if (await _dbService.InnExistsAsync(inn, _partnerId))
                {
                    global::System.Windows.MessageBox.Show("Партнёр с таким ИНН уже существует!",
                        "Ошибка", global::System.Windows.MessageBoxButton.OK,
                        global::System.Windows.MessageBoxImage.Warning);
                    return;
                }

                var model = new PartnerEditModel
                {
                    Id = _partnerId,
                    PartnerType = type,
                    PartnerName = name,
                    Director = director,
                    Email = email,
                    Phone = phone,
                    LegalAddress = address,
                    Inn = inn,
                    Rating = rating
                };

                if (_partnerId == null)
                {
                    await _dbService.InsertPartnerAsync(model);
                    global::System.Windows.MessageBox.Show("Партнёр добавлен!", "Успех",
                        global::System.Windows.MessageBoxButton.OK,
                        global::System.Windows.MessageBoxImage.Information);
                }
                else
                {
                    await _dbService.UpdatePartnerAsync(model);
                    global::System.Windows.MessageBox.Show("Данные обновлены!", "Успех",
                        global::System.Windows.MessageBoxButton.OK,
                        global::System.Windows.MessageBoxImage.Information);
                }

                this.DialogResult = true;
                this.Close();
            }
            catch (Exception ex)
            {
                global::System.Windows.MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка БД",
                    global::System.Windows.MessageBoxButton.OK,
                    global::System.Windows.MessageBoxImage.Error);
            }
        }

        private void CancelBtn_Click(object sender, global::System.Windows.RoutedEventArgs e)
        {
            this.DialogResult = false;
            this.Close();
        }
    }
}